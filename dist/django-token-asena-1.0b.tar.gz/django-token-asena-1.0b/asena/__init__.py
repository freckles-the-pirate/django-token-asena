import logging, pprint
logger = logging.getLogger('to_terminal')

#import sys, os
#from django.db import models
#BASE_DIR=os.path.dirname(os.path.abspath(__file__))
#sys.path.insert(0, BASE_DIR)
#logger.debug("Inserted %s. Now sys.path is: %s"%(BASE_DIR,
            #pprint.pformat(sys.path)))
    
#from . import (
    #admin,
    #fields,
    #forms,
    #models,
    #urls,
    #utils,
    #views,
    #widgets,
#)